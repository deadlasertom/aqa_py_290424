# Робота з файлами - Csv, json, xml

Складність:  середня

# task 1

Візміть два файли з теки
[ideas_for_test/work_with_csv](/ideas_for_test/work_with_csv)
порівняйте на наявність дублікатів і приберіть їх.
Результат запишіть у файл result_<your_second_name>.csv

# task 2

Провалідуйте, чи усі файли у папці
[ideas_for_test/work_with_json](/ideas_for_test/work_with_json)
є валідними json.
результат для невалідного файлу виведіть через print та у файл json__<your_second_name>.log

# task 3

Для файла [ideas_for_test/work_with_xml/groups.xml](/ideas_for_test/work_with_xml/groups.xml)
створіть функцію  пошуку по group/number і
повернення значення timingExbytes/incoming
результат виведіть у консоль через  print

# Як робити домашне завдання у Git:

## 0. ОБОВ’ЯЗКОВО створити нову гілку

1. **Виконати ДЗ у окремому файлі homework_<#lesson>.py**
2. **Закомітити створений код**
3. **Створити ПУЛ-РЕКВЕСТ у власний репозиторій У ГІЛКУ main**
4. **Назначити ревьювером викладача**
5. **Посилання на PR вставити у форму відповіді**