# ####["1,2,3,4",
#     "1,2,3,4,50"
#     "qwerty1,2,3"]
    
#     Для кожного елементу списку виведіть суму всіх чисел (створіть нову функцію для цього).
    
#     Якщо є символи, що не є числами (”qwerty1,2,3” у прикладі), вам потрібно зловити вийняток і вивести “Не можу це зробити!”
    
#     Використовуйте блок try\except, щоб уникнути інших символів, окрім чисел у списку.
    
#     Для цього прикладу правильний вивід буде - 10, 60, “Не можу це зробити”

test_list = ["1,3,5,7,9", "2,4,6,8,10", "1,2,3,4,5,6,7,8,9,10", "abcdef"]
test_list_2 = ["1,3,5,7,9", "2,4,6,8,10", "1,2,3,4,5,6,7,8,9,10"]
# def list_calk (list):
#     """calculates sum of all numbers in list""" 
#     result_list = [sum(i) for i in list]
#     return (result_list)
# task_1 = (list_calk)
# print (task_1(test_list_2))

def list_calk (str_list):
    """a"""
    counter = []
    try:
        for i in str_list:
            num_st = i.split(",")
            num = [int(n) for n in num_st]
            num_sum = sum(num)
            counter.append(num_sum)
        return counter
    except: ValueError:
        return 'Не можу це зробити'
task = list_calk(test_list)
print (task)

